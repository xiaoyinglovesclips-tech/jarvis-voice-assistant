package com.example.jarvis.data

import com.google.gson.annotations.SerializedName

// ChatGPT Models
data class ChatGPTRequest(
    val model: String = "gpt-4o-mini",
    val messages: List<ChatMessage>,
    val temperature: Double = 0.7
)

data class ChatMessage(
    val role: String,
    val content: String
)

data class ChatGPTResponse(
    val choices: List<Choice>
)

data class Choice(
    val message: ChatMessage
)

// SearchAPI Models
data class SearchAPIResponse(
    val organic_results: List<SearchResult>?
)

data class SearchResult(
    val title: String,
    val snippet: String,
    val link: String
)

// ElevenLabs Models
data class ElevenLabsRequest(
    val text: String,
    val voice_settings: VoiceSettings
)

data class VoiceSettings(
    val stability: Double = 0.7,
    val similarity_boost: Double = 0.7
)

// Chat UI Models
data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
