package com.example.jarvis.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

// Chat message model
data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val language: String = "en"
)

// Permission levels
enum class PermissionLevel {
    LEVEL_1,  // Basic voice queries only
    LEVEL_2,  // Phone control (calls, SMS, alarms)
    LEVEL_3   // Advanced control (lock, factory reset)
}

// Audit log for security tracking
@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val action: String,
    val permissionLevel: String,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String = "",
    val success: Boolean = true
)

// User preferences
data class UserPreferences(
    val apiKeyOpenAI: String = "",
    val apiKeyElevenLabs: String = "",
    val apiKeySearch: String = "",
    val voiceId: String = "21m00Tcm4TlvDq8ikWAM",
    val language: String = "en",
    val permissionLevel: PermissionLevel = PermissionLevel.LEVEL_1,
    val isJarvisEnabled: Boolean = true,
    val alwaysListening: Boolean = false,
    val privacyMode: Boolean = false
)

// Hinglish support
data class HinglishTranslation(
    val english: String,
    val hinglish: String,
    val hindi: String
)
