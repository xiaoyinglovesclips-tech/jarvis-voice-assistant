package com.example.jarvis.utils

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "jarvis_prefs")

class PreferencesManager(private val context: Context) {
    companion object {
        private val OPENAI_KEY = stringPreferencesKey("openai_key")
        private val ELEVENLABS_KEY = stringPreferencesKey("elevenlabs_key")
        private val SEARCHAPI_KEY = stringPreferencesKey("searchapi_key")
        private val VOICE_ID = stringPreferencesKey("voice_id")
    }

    val openaiKey: Flow<String> = context.dataStore.data.map { it[OPENAI_KEY] ?: "" }
    val elevenLabsKey: Flow<String> = context.dataStore.data.map { it[ELEVENLABS_KEY] ?: "" }
    val searchApiKey: Flow<String> = context.dataStore.data.map { it[SEARCHAPI_KEY] ?: "" }
    val voiceId: Flow<String> = context.dataStore.data.map { it[VOICE_ID] ?: "21m00Tcm4TlvDq8ikWAM" }

    suspend fun saveOpenaiKey(key: String) {
        context.dataStore.edit { it[OPENAI_KEY] = key }
    }

    suspend fun saveElevenLabsKey(key: String) {
        context.dataStore.edit { it[ELEVENLABS_KEY] = key }
    }

    suspend fun saveSearchApiKey(key: String) {
        context.dataStore.edit { it[SEARCHAPI_KEY] = key }
    }

    suspend fun saveVoiceId(id: String) {
        context.dataStore.edit { it[VOICE_ID] = id }
    }
}
