package com.example.jarvis.services

import com.example.jarvis.data.HinglishTranslation

class BilingualSupport {
    private val hinglishDictionary = mapOf(
        "hello" to HinglishTranslation("hello", "namaste", "नमस्ते"),
        "goodbye" to HinglishTranslation("goodbye", "phir milenge", "फिर मिलेंगे"),
        "thank you" to HinglishTranslation("thank you", "shukriya", "शुक्रिया"),
        "yes" to HinglishTranslation("yes", "haan", "हाँ"),
        "no" to HinglishTranslation("no", "nahi", "नहीं"),
        "what is your name" to HinglishTranslation("what is your name", "tumhara naam kya hai", "तुम्हारा नाम क्या है"),
        "i am jarvis" to HinglishTranslation("i am jarvis", "main jarvis hoon", "मैं जार्विस हूँ"),
        "how are you" to HinglishTranslation("how are you", "tum kaisa ho", "तुम कैसे हो"),
        "i am fine" to HinglishTranslation("i am fine", "main theek hoon", "मैं ठीक हूँ")
    )

    fun detectLanguage(text: String): String {
        return when {
            text.any { it.code in 0x0900..0x097F } -> "hi"  // Devanagari script
            text.lowercase().contains(Regex("[a-z]")) -> "en"
            else -> "en"
        }
    }

    fun translateToHinglish(text: String): String {
        return hinglishDictionary[text.lowercase()]?.hinglish ?: text
    }

    fun translateToHindi(text: String): String {
        return hinglishDictionary[text.lowercase()]?.hindi ?: text
    }

    fun isHinglishQuery(text: String): Boolean {
        return text.lowercase().contains(Regex("(kya|hai|hoon|tum|main|aur|ya|ke|ka)"))
    }
}
