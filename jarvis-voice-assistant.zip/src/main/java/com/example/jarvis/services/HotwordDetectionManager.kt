package com.example.jarvis.services

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class HotwordDetectionManager(private val context: Context) {
    private val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
    
    private val _hotwordDetected = MutableStateFlow(false)
    val hotwordDetected: StateFlow<Boolean> = _hotwordDetected
    
    private val _isListeningForHotword = MutableStateFlow(false)
    val isListeningForHotword: StateFlow<Boolean> = _isListeningForHotword

    private val hotwords = listOf("jarvis", "hey jarvis", "jarvis wake up")

    fun startHotwordDetection() {
        _isListeningForHotword.value = true
        _hotwordDetected.value = false

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 5000)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                _isListeningForHotword.value = false
                // Restart listening on error
                startHotwordDetection()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val recognized = matches[0].lowercase()
                    if (hotwords.any { recognized.contains(it) }) {
                        _hotwordDetected.value = true
                    }
                }
                _isListeningForHotword.value = false
                // Continue listening for hotword
                startHotwordDetection()
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer.startListening(intent)
    }

    fun stopHotwordDetection() {
        _isListeningForHotword.value = false
        speechRecognizer.stopListening()
    }

    fun release() {
        speechRecognizer.destroy()
    }
}
