package com.example.jarvis.services

import com.example.jarvis.data.ChatGPTRequest
import com.example.jarvis.data.ChatGPTResponse
import com.example.jarvis.data.ChatMessage
import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class ChatService(private val apiKey: String) {
    private val client = OkHttpClient()
    private val gson = Gson()

    suspend fun sendMessage(userMessage: String): Result<String> = try {
        val request = ChatGPTRequest(
            messages = listOf(
                ChatMessage(role = "user", content = userMessage)
            )
        )

        val requestBody = gson.toJson(request).toRequestBody()
        val httpRequest = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        val response = client.newCall(httpRequest).execute()
        val responseBody = response.body?.string() ?: return Result.failure(Exception("Empty response"))

        val chatResponse = gson.fromJson(responseBody, ChatGPTResponse::class.java)
        val assistantMessage = chatResponse.choices.firstOrNull()?.message?.content
            ?: return Result.failure(Exception("No response from ChatGPT"))

        Result.success(assistantMessage)
    } catch (e: Exception) {
        Result.failure(e)
    }
}
