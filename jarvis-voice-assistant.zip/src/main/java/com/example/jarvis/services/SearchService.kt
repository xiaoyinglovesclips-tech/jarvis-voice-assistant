package com.example.jarvis.services

import com.example.jarvis.data.SearchAPIResponse
import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request

class SearchService(private val apiKey: String) {
    private val client = OkHttpClient()
    private val gson = Gson()

    suspend fun search(query: String): Result<String> = try {
        val url = "https://serpapi.com/search.json?q=${query.replace(" ", "+")}&api_key=$apiKey"
        
        val request = Request.Builder()
            .url(url)
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return Result.failure(Exception("Empty response"))

        val searchResponse = gson.fromJson(responseBody, SearchAPIResponse::class.java)
        val results = searchResponse.organic_results?.take(3)?.joinToString("\n\n") { result ->
            "${result.title}\n${result.snippet}"
        } ?: return Result.failure(Exception("No search results"))

        Result.success(results)
    } catch (e: Exception) {
        Result.failure(e)
    }
}
