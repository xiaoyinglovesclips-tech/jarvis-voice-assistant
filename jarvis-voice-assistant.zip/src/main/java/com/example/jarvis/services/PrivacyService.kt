package com.example.jarvis.services

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.edit
import androidx.datastore.preferences.booleanPreferencesKey
import kotlinx.coroutines.flow.map

class PrivacyService(private val context: Context) {
    private val dataStore = context.preferencesDataStore("privacy_settings")
    
    private val privacyModeKey = booleanPreferencesKey("privacy_mode")
    private val noUrlPolicyKey = booleanPreferencesKey("no_url_policy")
    private val jarvisEnabledKey = booleanPreferencesKey("jarvis_enabled")

    val privacyMode = dataStore.data.map { it[privacyModeKey] ?: false }
    val noUrlPolicy = dataStore.data.map { it[noUrlPolicyKey] ?: true }
    val jarvisEnabled = dataStore.data.map { it[jarvisEnabledKey] ?: true }

    suspend fun setPrivacyMode(enabled: Boolean) {
        dataStore.edit { it[privacyModeKey] = enabled }
    }

    suspend fun setNoUrlPolicy(enabled: Boolean) {
        dataStore.edit { it[noUrlPolicyKey] = enabled }
    }

    suspend fun disableJarvis() {
        dataStore.edit { it[jarvisEnabledKey] = false }
    }

    suspend fun enableJarvis() {
        dataStore.edit { it[jarvisEnabledKey] = true }
    }

    fun containsUrl(text: String): Boolean {
        val urlPattern = Regex("(https?://|www\\.|\\.[a-z]{2,})")
        return urlPattern.containsMatchIn(text)
    }

    fun filterUrlsFromResponse(text: String): String {
        return text.replace(Regex("(https?://[^\\s]+|www\\.[^\\s]+)"), "[URL BLOCKED]")
    }
}
