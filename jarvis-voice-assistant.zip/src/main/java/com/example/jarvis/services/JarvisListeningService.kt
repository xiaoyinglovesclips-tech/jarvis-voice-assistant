package com.example.jarvis.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class JarvisListeningService : Service() {
    private lateinit var hotwordDetectionManager: HotwordDetectionManager

    override fun onCreate() {
        super.onCreate()
        hotwordDetectionManager = HotwordDetectionManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Create notification for foreground service
        val notification = NotificationCompat.Builder(this, "jarvis_channel")
            .setContentTitle("Jarvis Listening")
            .setContentText("Waiting for 'Hey Jarvis' wake word...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        startForeground(1, notification)
        hotwordDetectionManager.startHotwordDetection()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        hotwordDetectionManager.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
