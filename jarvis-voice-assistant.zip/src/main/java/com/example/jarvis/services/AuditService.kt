package com.example.jarvis.services

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.edit
import androidx.datastore.preferences.stringPreferencesKey
import com.google.gson.Gson
import com.example.jarvis.data.AuditLog
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuditService(private val context: Context) {
    private val dataStore = context.preferencesDataStore("audit_logs")
    private val gson = Gson()
    private val auditLogsKey = stringPreferencesKey("audit_logs")

    suspend fun logAction(
        action: String,
        permissionLevel: String,
        details: String = "",
        success: Boolean = true
    ) {
        val log = AuditLog(
            action = action,
            permissionLevel = permissionLevel,
            details = details,
            success = success
        )

        dataStore.edit { preferences ->
            val existingLogs = preferences[auditLogsKey]?.let {
                gson.fromJson(it, Array<AuditLog>::class.java).toMutableList()
            } ?: mutableListOf()

            existingLogs.add(log)
            preferences[auditLogsKey] = gson.toJson(existingLogs)
        }
    }

    fun getAuditLogs() = dataStore.data.map { preferences ->
        preferences[auditLogsKey]?.let {
            gson.fromJson(it, Array<AuditLog>::class.java).toList()
        } ?: emptyList()
    }

    suspend fun clearAuditLogs() {
        dataStore.edit { preferences ->
            preferences.remove(auditLogsKey)
        }
    }

    fun formatAuditLog(log: AuditLog): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val date = dateFormat.format(Date(log.timestamp))
        return "$date | ${log.action} | Level: ${log.permissionLevel} | Success: ${log.success}"
    }
}
