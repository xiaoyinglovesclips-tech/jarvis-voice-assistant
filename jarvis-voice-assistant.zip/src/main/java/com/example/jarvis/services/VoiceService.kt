package com.example.jarvis.services

import android.content.Context
import android.media.MediaPlayer
import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class VoiceService(private val context: Context, private val apiKey: String) {
    private val client = OkHttpClient()
    private val gson = Gson()
    private var mediaPlayer: MediaPlayer? = null

    suspend fun textToSpeech(text: String, voiceId: String = "21m00Tcm4TlvDq8ikWAM"): Result<Unit> = try {
        val requestBody = """
            {
                "text": "$text",
                "voice_settings": {
                    "stability": 0.7,
                    "similarity_boost": 0.7
                }
            }
        """.trimIndent().toRequestBody()

        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
            .addHeader("xi-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()
        val audioBytes = response.body?.bytes() ?: return Result.failure(Exception("No audio data"))

        // Save audio to cache
        val audioFile = File(context.cacheDir, "response_audio.mp3")
        audioFile.writeBytes(audioBytes)

        // Play audio
        playAudio(audioFile.absolutePath)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    private fun playAudio(filePath: String) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(filePath)
            prepare()
            start()
        }
    }

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
