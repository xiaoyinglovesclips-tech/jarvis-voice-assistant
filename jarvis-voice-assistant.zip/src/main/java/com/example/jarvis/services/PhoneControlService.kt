package com.example.jarvis.services

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

class PhoneControlService(private val context: Context) {

    // Make a phone call
    fun makeCall(phoneNumber: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
            }
            ContextCompat.startForegroundService(context, intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Send SMS
    fun sendSMS(phoneNumber: String, message: String): Boolean {
        return try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Set alarm
    fun setAlarm(hour: Int, minute: Int, label: String = "Jarvis Alarm"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Lock screen (requires Device Owner or Accessibility Service)
    fun lockScreen(): Boolean {
        return try {
            val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            // This requires Device Owner mode or Accessibility Service
            false
        } catch (e: Exception) {
            false
        }
    }

    // Get contact by name
    fun getContactNumber(contactName: String): String? {
        return try {
            val cursor = context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
                arrayOf("%$contactName%"),
                null
            )
            
            cursor?.use {
                if (it.moveToFirst()) {
                    val contactId = it.getString(it.getColumnIndex(ContactsContract.Contacts._ID))
                    val phoneCursor = context.contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )
                    
                    phoneCursor?.use { pc ->
                        if (pc.moveToFirst()) {
                            return pc.getString(pc.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                        }
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
