package com.example.jarvis.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.jarvis.data.PermissionLevel
import com.example.jarvis.services.AuditService
import com.example.jarvis.services.PrivacyService
import com.example.jarvis.utils.PreferencesManager
import kotlinx.coroutines.launch

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferencesManager = PreferencesManager(this)
        val privacyService = PrivacyService(this)
        val auditService = AuditService(this)

        setContent {
            JarvisTheme {
                SettingsScreen(
                    preferencesManager = preferencesManager,
                    privacyService = privacyService,
                    auditService = auditService,
                    onBackClick = { finish() }
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    privacyService: PrivacyService,
    auditService: AuditService,
    onBackClick: () -> Unit
) {
    var openaiKey by remember { mutableStateOf("") }
    var elevenLabsKey by remember { mutableStateOf("") }
    var searchApiKey by remember { mutableStateOf("") }
    var voiceId by remember { mutableStateOf("21m00Tcm4TlvDq8ikWAM") }
    
    // <CHANGE> Added privacy and security controls
    var privacyMode by remember { mutableStateOf(false) }
    var noUrlPolicy by remember { mutableStateOf(true) }
    var jarvisEnabled by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(0) }
    var auditLogs by remember { mutableStateOf<List<String>>(emptyList()) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        preferencesManager.openaiKey.collect { openaiKey = it }
    }

    LaunchedEffect(Unit) {
        preferencesManager.elevenLabsKey.collect { elevenLabsKey = it }
    }

    LaunchedEffect(Unit) {
        preferencesManager.searchApiKey.collect { searchApiKey = it }
    }

    LaunchedEffect(Unit) {
        preferencesManager.voiceId.collect { voiceId = it }
    }

    LaunchedEffect(Unit) {
        privacyService.privacyMode.collect { privacyMode = it }
    }

    LaunchedEffect(Unit) {
        privacyService.noUrlPolicy.collect { noUrlPolicy = it }
    }

    LaunchedEffect(Unit) {
        privacyService.jarvisEnabled.collect { jarvisEnabled = it }
    }

    LaunchedEffect(Unit) {
        auditService.getAuditLogs().collect { logs ->
            auditLogs = logs.map { auditService.formatAuditLog(it) }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E27))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF00D9FF)
                    )
                }
                Text(
                    "SETTINGS",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00D9FF)
                )
                Spacer(modifier = Modifier.width(48.dp))
            }

            // <CHANGE> Added tab navigation for different settings sections
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color(0xFF1A1F3A),
                contentColor = Color(0xFF00D9FF)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("API Keys") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Privacy") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Audit") }
                )
            }

            // Content based on selected tab
            when (selectedTab) {
                0 -> APIKeysTab(
                    openaiKey = openaiKey,
                    elevenLabsKey = elevenLabsKey,
                    searchApiKey = searchApiKey,
                    voiceId = voiceId,
                    onOpenaiKeyChange = { openaiKey = it },
                    onElevenLabsKeyChange = { elevenLabsKey = it },
                    onSearchApiKeyChange = { searchApiKey = it },
                    onVoiceIdChange = { voiceId = it },
                    onSaveOpenai = { scope.launch { preferencesManager.saveOpenaiKey(openaiKey) } },
                    onSaveElevenLabs = { scope.launch { preferencesManager.saveElevenLabsKey(elevenLabsKey) } },
                    onSaveSearchApi = { scope.launch { preferencesManager.saveSearchApiKey(searchApiKey) } },
                    onSaveVoiceId = { scope.launch { preferencesManager.saveVoiceId(voiceId) } }
                )
                1 -> PrivacyTab(
                    privacyMode = privacyMode,
                    noUrlPolicy = noUrlPolicy,
                    jarvisEnabled = jarvisEnabled,
                    onPrivacyModeChange = { scope.launch { privacyService.setPrivacyMode(it) } },
                    onNoUrlPolicyChange = { scope.launch { privacyService.setNoUrlPolicy(it) } },
                    onDisableJarvis = { scope.launch { privacyService.disableJarvis() } },
                    onEnableJarvis = { scope.launch { privacyService.enableJarvis() } }
                )
                2 -> AuditTab(auditLogs = auditLogs)
            }
        }
    }
}

@Composable
fun APIKeysTab(
    openaiKey: String,
    elevenLabsKey: String,
    searchApiKey: String,
    voiceId: String,
    onOpenaiKeyChange: (String) -> Unit,
    onElevenLabsKeyChange: (String) -> Unit,
    onSearchApiKeyChange: (String) -> Unit,
    onVoiceIdChange: (String) -> Unit,
    onSaveOpenai: () -> Unit,
    onSaveElevenLabs: () -> Unit,
    onSaveSearchApi: () -> Unit,
    onSaveVoiceId: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        SettingsTextField(
            label = "OpenAI API Key",
            value = openaiKey,
            onValueChange = onOpenaiKeyChange,
            onSave = onSaveOpenai
        )

        SettingsTextField(
            label = "ElevenLabs API Key",
            value = elevenLabsKey,
            onValueChange = onElevenLabsKeyChange,
            onSave = onSaveElevenLabs
        )

        SettingsTextField(
            label = "SearchAPI Key",
            value = searchApiKey,
            onValueChange = onSearchApiKeyChange,
            onSave = onSaveSearchApi
        )

        SettingsTextField(
            label = "ElevenLabs Voice ID",
            value = voiceId,
            onValueChange = onVoiceIdChange,
            onSave = onSaveVoiceId
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Voice IDs:\n• 21m00Tcm4TlvDq8ikWAM (Rachel)\n• EXAVITQu4vr4xnSDxMaL (Bella)\n• TxGEqnHWrfWFTfGW9XjX (Josh)",
            color = Color(0xFF00FF88),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

@Composable
fun PrivacyTab(
    privacyMode: Boolean,
    noUrlPolicy: Boolean,
    jarvisEnabled: Boolean,
    onPrivacyModeChange: (Boolean) -> Unit,
    onNoUrlPolicyChange: (Boolean) -> Unit,
    onDisableJarvis: () -> Unit,
    onEnableJarvis: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "Privacy & Security",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00D9FF),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Privacy Mode Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    "Privacy Mode",
                    color = Color(0xFF00D9FF),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Disable data collection",
                    color = Color(0xFF00FF88),
                    fontSize = 12.sp
                )
            }
            Switch(
                checked = privacyMode,
                onCheckedChange = onPrivacyModeChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF00FF88),
                    checkedTrackColor = Color(0xFF1A4D5C)
                )
            )
        }

        Divider(color = Color(0xFF1A1F3A), thickness = 1.dp)

        // No URL Policy Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    "Block URLs",
                    color = Color(0xFF00D9FF),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Jarvis won't read URLs",
                    color = Color(0xFF00FF88),
                    fontSize = 12.sp
                )
            }
            Switch(
                checked = noUrlPolicy,
                onCheckedChange = onNoUrlPolicyChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF00FF88),
                    checkedTrackColor = Color(0xFF1A4D5C)
                )
            )
        }

        Divider(color = Color(0xFF1A1F3A), thickness = 1.dp)

        Spacer(modifier = Modifier.height(24.dp))

        // Kill Switch
        Text(
            "Kill Switch",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFF0000),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onDisableJarvis,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000))
            ) {
                Text("Disable Jarvis", color = Color.White)
            }
            Button(
                onClick = onEnableJarvis,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF88))
            ) {
                Text("Enable Jarvis", color = Color(0xFF0A0E27))
            }
        }
    }
}

@Composable
fun AuditTab(auditLogs: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "Audit Logs",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF00D9FF),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (auditLogs.isEmpty()) {
            Text(
                "No audit logs yet",
                color = Color(0xFF00FF88),
                fontSize = 14.sp,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            auditLogs.forEach { log ->
                Text(
                    log,
                    color = Color(0xFF00FF88),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Divider(color = Color(0xFF1A1F3A), thickness = 0.5.dp)
            }
        }
    }
}

@Composable
fun SettingsTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 12.dp)) {
        Text(
            label,
            color = Color(0xFF00D9FF),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            TextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1A1F3A),
                    unfocusedContainerColor = Color(0xFF1A1F3A),
                    focusedTextColor = Color(0xFF00D9FF),
                    unfocusedTextColor = Color(0xFF00D9FF)
                )
            )
            Button(
                onClick = onSave,
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(start = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF88))
            ) {
                Text("Save", color = Color(0xFF0A0E27), fontWeight = FontWeight.Bold)
            }
        }
    }
}
