package com.example.jarvis.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.jarvis.data.ChatMessage
import com.example.jarvis.services.*
import com.example.jarvis.utils.PreferencesManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var speechRecognizerManager: SpeechRecognizerManager
    private lateinit var hotwordDetectionManager: HotwordDetectionManager
    private lateinit var phoneControlService: PhoneControlService
    private lateinit var auditService: AuditService
    private lateinit var privacyService: PrivacyService
    private lateinit var bilingualSupport: BilingualSupport
    
    private var chatService: ChatService? = null
    private var searchService: SearchService? = null
    private var voiceService: VoiceService? = null

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle permissions
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferencesManager = PreferencesManager(this)
        speechRecognizerManager = SpeechRecognizerManager(this)
        hotwordDetectionManager = HotwordDetectionManager(this)
        phoneControlService = PhoneControlService(this)
        auditService = AuditService(this)
        privacyService = PrivacyService(this)
        bilingualSupport = BilingualSupport()

        requestPermissions()

        lifecycleScope.launch {
            preferencesManager.openaiKey.collect { key ->
                if (key.isNotEmpty()) chatService = ChatService(key)
            }
        }

        lifecycleScope.launch {
            preferencesManager.elevenLabsKey.collect { key ->
                if (key.isNotEmpty()) voiceService = VoiceService(this@MainActivity, key)
            }
        }

        lifecycleScope.launch {
            preferencesManager.searchApiKey.collect { key ->
                if (key.isNotEmpty()) searchService = SearchService(key)
            }
        }

        setContent {
            JarvisTheme {
                MainScreen(
                    speechRecognizerManager = speechRecognizerManager,
                    hotwordDetectionManager = hotwordDetectionManager,
                    chatService = chatService,
                    searchService = searchService,
                    voiceService = voiceService,
                    phoneControlService = phoneControlService,
                    auditService = auditService,
                    privacyService = privacyService,
                    bilingualSupport = bilingualSupport,
                    preferencesManager = preferencesManager,
                    onSettingsClick = { startActivity(Intent(this, SettingsActivity::class.java)) }
                )
            }
        }
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SCHEDULE_EXACT_ALARM
        )
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.FOREGROUND_SERVICE_MICROPHONE)
        }

        val permissionsToRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizerManager.release()
        hotwordDetectionManager.release()
        voiceService?.release()
    }
}

@Composable
fun MainScreen(
    speechRecognizerManager: SpeechRecognizerManager,
    hotwordDetectionManager: HotwordDetectionManager,
    chatService: ChatService?,
    searchService: SearchService?,
    voiceService: VoiceService?,
    phoneControlService: PhoneControlService,
    auditService: AuditService,
    privacyService: PrivacyService,
    bilingualSupport: BilingualSupport,
    preferencesManager: PreferencesManager,
    onSettingsClick: () -> Unit
) {
    val chatMessages = remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    val isListening by speechRecognizerManager.isListening.collectAsState()
    val recognizedText by speechRecognizerManager.recognizedText.collectAsState()
    val hotwordDetected by hotwordDetectionManager.hotwordDetected.collectAsState()
    val isProcessing = remember { mutableStateOf(false) }
    val voiceId by preferencesManager.voiceId.collectAsState(initial = "21m00Tcm4TlvDq8ikWAM")
    val listState = rememberLazyListState()
    val privacyMode by privacyService.privacyMode.collectAsState(initial = false)

    LaunchedEffect(hotwordDetected) {
        if (hotwordDetected) {
            speechRecognizerManager.startListening()
            hotwordDetectionManager._hotwordDetected.value = false
        }
    }

    LaunchedEffect(recognizedText) {
        if (recognizedText.isNotEmpty() && !isListening) {
            chatMessages.value = chatMessages.value + ChatMessage(text = recognizedText, isUser = true)
            isProcessing.value = true

            var response = if (isSearchQuery(recognizedText)) {
                searchService?.search(recognizedText)?.getOrNull() ?: "Search failed"
            } else {
                chatService?.sendMessage(recognizedText)?.getOrNull() ?: "Chat failed"
            }

            if (privacyService.containsUrl(response)) {
                response = privacyService.filterUrlsFromResponse(response)
            }

            chatMessages.value = chatMessages.value + ChatMessage(text = response, isUser = false)
            voiceService?.textToSpeech(response, voiceId)
            isProcessing.value = false
        }
    }

    LaunchedEffect(chatMessages.value.size) {
        if (chatMessages.value.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.value.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0E27))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header with holographic effect
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .shadow(8.dp, RoundedCornerShape(12.dp))
                    .background(Color(0xFF1A1F3A), RoundedCornerShape(12.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "JARVIS",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00D9FF)
                    )
                    Text(
                        "AI Voice Assistant",
                        fontSize = 12.sp,
                        color = Color(0xFF00FF88)
                    )
                }
                IconButton(onClick = onSettingsClick) {
                    Icon(
                        Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Color(0xFF00D9FF),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Chat Area
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                state = listState
            ) {
                items(chatMessages.value) { message ->
                    ChatBubble(message = message)
                }
            }

            // Mic Button with holographic animation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                HolographicMicButton(
                    isListening = isListening,
                    isProcessing = isProcessing.value,
                    hotwordDetected = hotwordDetected,
                    onClick = {
                        if (!isListening && !isProcessing.value) {
                            speechRecognizerManager.startListening()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (message.isUser) Color(0xFF1A4D5C) else Color(0xFF1A1F3A)
                )
                .shadow(4.dp, RoundedCornerShape(16.dp))
                .padding(12.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                text = message.text,
                color = if (message.isUser) Color(0xFF00D9FF) else Color(0xFF00FF88),
                fontSize = 14.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun HolographicMicButton(
    isListening: Boolean,
    isProcessing: Boolean,
    hotwordDetected: Boolean,
    onClick: () -> Unit
) {
    val composition by rememberLottieComposition(LottieCompositionSpec.Url("https://lottie.host/4db645ba-eeac-4e5f-8d52-a7e8c1b5c5f5/7JxwqXXcW3.json"))
    val buttonColor by animateColorAsState(
        targetValue = when {
            hotwordDetected -> Color(0xFFFF00FF)
            isListening || isProcessing -> Color(0xFF00FF88)
            else -> Color(0xFF00D9FF)
        }
    )

    Box(
        modifier = Modifier
            .size(120.dp)
            .shadow(16.dp, CircleShape)
            .background(buttonColor, CircleShape)
            .clip(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Button(
            onClick = onClick,
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape),
            colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
            enabled = !isProcessing
        ) {
            if (isListening || isProcessing) {
                LottieAnimation(
                    composition = composition,
                    modifier = Modifier.size(60.dp),
                    isPlaying = true,
                    iterations = Int.MAX_VALUE
                )
            } else if (hotwordDetected) {
                Text("🎤", fontSize = 40.sp)
            } else {
                Text("🎤", fontSize = 40.sp)
            }
        }
    }
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00D9FF),
            secondary = Color(0xFF00FF88),
            background = Color(0xFF0A0E27),
            surface = Color(0xFF1A1F3A)
        )
    ) {
        content()
    }
}

private fun isSearchQuery(text: String): Boolean {
    val searchKeywords = listOf("search", "find", "what is", "google", "look up", "dhundo", "khoj")
    return searchKeywords.any { text.lowercase().contains(it) }
}
