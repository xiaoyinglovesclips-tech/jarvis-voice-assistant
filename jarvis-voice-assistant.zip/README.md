# JARVIS - Sci-Fi Voice Assistant for Android

A futuristic voice-controlled AI assistant inspired by Tony Stark's JARVIS. Responds to "Hey Jarvis" wake word and provides intelligent responses using ChatGPT-4o-mini, with real-time web search capabilities and natural voice output.

## Features

- **Voice Activation**: Wake word detection for "Hey Jarvis"
- **Speech Recognition**: Android SpeechRecognizer for accurate voice-to-text conversion
- **AI Conversations**: ChatGPT-4o-mini integration for intelligent responses
- **Web Search**: Real-time search results via SearchAPI
- **Text-to-Speech**: ElevenLabs API for natural voice responses
- **Futuristic UI**: Neon blue/black theme with animations
- **Secure Storage**: DataStore for API key management
- **Lottie Animations**: Smooth voice waveform animations

## Setup Instructions

### 1. Prerequisites
- Android Studio (latest version)
- Android SDK 24+
- Kotlin 1.9+

### 2. API Keys Required

Get these API keys from their respective services:

#### OpenAI (ChatGPT-4o-mini)
1. Go to https://platform.openai.com/api-keys
2. Create a new API key
3. Copy the key

#### ElevenLabs (Text-to-Speech)
1. Go to https://elevenlabs.io/
2. Sign up and get your API key
3. Note your Voice ID (default: 21m00Tcm4TlvDq8ikWAM for Rachel)

#### SearchAPI (Web Search)
1. Go to https://serpapi.com/
2. Sign up and get your API key

### 3. Installation

1. Clone or download this project
2. Open in Android Studio
3. Build the project: `Build > Make Project`
4. Run on emulator or device: `Run > Run 'app'`

### 4. Configure API Keys

1. Launch the app
2. Tap the settings icon (⚙️) in the top right
3. Enter your API keys:
   - OpenAI API Key
   - ElevenLabs API Key
   - SearchAPI Key
   - ElevenLabs Voice ID (optional)
4. Tap "Save" for each key

### 5. Grant Permissions

When first launched, grant:
- **RECORD_AUDIO**: For voice input
- **INTERNET**: For API calls
- **FOREGROUND_SERVICE**: For continuous listening (optional)

## Usage

1. **Activate**: Say "Hey Jarvis" or tap the microphone button
2. **Speak**: Ask a question or give a command
3. **Listen**: Jarvis responds with voice and text

### Example Queries

- "What is the weather today?" (triggers search)
- "Tell me about quantum computing" (ChatGPT response)
- "Search for latest AI news" (web search)
- "How do I make pasta?" (ChatGPT response)

## Project Structure

\`\`\`
jarvis-voice-assistant/
├── src/main/java/com/example/jarvis/
│   ├── data/
│   │   └── ApiModels.kt          # Data classes for API responses
│   ├── services/
│   │   ├── SpeechRecognizerManager.kt  # Voice input handling
│   │   ├── ChatService.kt              # ChatGPT integration
│   │   ├── SearchService.kt            # SearchAPI integration
│   │   └── VoiceService.kt             # ElevenLabs TTS
│   ├── ui/
│   │   ├── MainActivity.kt        # Main chat interface
│   │   └── SettingsActivity.kt    # API key configuration
│   └── utils/
│       └── PreferencesManager.kt  # Secure key storage
├── src/main/AndroidManifest.xml
└── build.gradle.kts
\`\`\`

## Architecture

- **MVVM Pattern**: Clean separation of concerns
- **Coroutines**: Async operations for API calls
- **Jetpack Compose**: Modern UI framework
- **DataStore**: Secure preference storage
- **OkHttp**: HTTP client for API requests

## Customization

### Change Voice
In Settings, update the Voice ID:
- Rachel: `21m00Tcm4TlvDq8ikWAM`
- Bella: `EXAVITQu4vr4xnSDxMaL`
- Josh: `TxGEqnHWrfWFTfGW9XjX`

### Modify Colors
Edit `JarvisTheme` in MainActivity.kt:
- Primary: `Color(0xFF00D9FF)` (Cyan)
- Secondary: `Color(0xFF00FF88)` (Green)
- Background: `Color(0xFF0A0E27)` (Dark Blue)

### Adjust Search Detection
Modify `isSearchQuery()` function in MainActivity.kt to add/remove keywords

## Troubleshooting

### "No response from API"
- Verify API keys are correct in Settings
- Check internet connection
- Ensure API keys have sufficient credits

### "Speech recognition not working"
- Grant RECORD_AUDIO permission
- Check microphone is working
- Ensure language is set to English

### "No audio output"
- Verify ElevenLabs API key is correct
- Check device volume is not muted
- Ensure speaker is connected

## Future Enhancements

- Always-listening mode with wake word detection
- Chat history persistence with Room database
- Multiple language support
- Custom voice training
- Integration with smart home devices
- Offline mode with local models

## License

MIT License - Feel free to use and modify

## Support

For issues or questions, check the troubleshooting section or review the API documentation:
- OpenAI: https://platform.openai.com/docs
- ElevenLabs: https://elevenlabs.io/docs
- SearchAPI: https://serpapi.com/docs
